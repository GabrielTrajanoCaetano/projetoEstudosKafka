package io.github.projetoparadesenvolvimento.icompras.servicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
